class LiquidWidgetsCollection extends Backbone.Collection{get model(){return LiquidWidgetBaseModel}}

class LiquidBaseModel extends Backbone.Model{}LiquidBaseModel.urlRoot=LiquidBaseModel.url=LiquidBaseModel.save=LiquidBaseModel.sync=LiquidBaseModel.fetch=_.noop;

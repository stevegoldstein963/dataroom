<?php

include_once( get_template_directory() . '/theme/metaboxes/post-format.php' );

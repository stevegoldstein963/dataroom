<div class="lqd-sidebar-container mb-60">
	<aside class="lqd-main-sidebar">
		<?php dynamic_sidebar( liquid()->layout->sidebars['sidebar'] ) ?>
	</aside>
</div>
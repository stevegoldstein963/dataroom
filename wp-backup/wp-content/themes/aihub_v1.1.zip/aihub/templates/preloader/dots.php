<div class="lqd-preloader-wrap lqd-preloader-dots" data-preloader-options='{ "animationType": "fade" }'>
	<div class="lqd-preloader-inner">

		<div class="lqd-preloader-dots-el">
			<div class="lqd-preloader-dots-dot"></div>
			<div class="lqd-preloader-dots-dot"></div>
			<div class="lqd-preloader-dots-dot"></div>
		</div>

	</div>
</div>
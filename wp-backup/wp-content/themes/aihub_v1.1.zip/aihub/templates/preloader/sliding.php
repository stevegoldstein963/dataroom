<div class="lqd-preloader-wrap lqd-preloader-sliding" data-preloader-options='{ "animationType": "slide", "animationTargets": ".lqd-preloader-sliding-el" }'>
	<div class="lqd-preloader-inner">
		<div class="lqd-preloader-sliding-el absolute top-0 start-0"></div>
	</div>
</div>
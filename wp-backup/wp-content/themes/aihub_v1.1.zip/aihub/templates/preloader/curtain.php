<div class="lqd-preloader-wrap lqd-preloader-curtain" data-preloader-options='{ "animationType": "slide", "animationTargets": ".lqd-preloader-curtain-el", "stagger": 215 }'>
	<div class="lqd-preloader-inner">

		<div class="lqd-preloader-curtain-el lqd-preloader-curtain-front absolute top-0 start-0"></div>
		<div class="lqd-preloader-curtain-el lqd-preloader-curtain-back absolute top-0 start-0"></div>

	</div>
</div>
<div class="lqd-preloader-wrap lqd-preloader-dissolve"
data-preloader-options='{ "animationType": "scale", "animationTargets": ".lqd-preloader-dissolve-el", "stagger": 12, "dir": "y", "duration": 600 }'>
	<div class="lqd-preloader-inner flex flex-col">

		<?php for ( $i = 0; $i <= 26; $i++ ) : ?>
			<div class="lqd-preloader-dissolve-el w-full grow"></div>
		<?php endfor; ?>

	</div>
</div>
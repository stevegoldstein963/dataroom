<div class="lqd-preloader-wrap lqd-preloader-fade" data-preloader-options='{ "animationType": "fade" }'>
	<div class="lqd-preloader-inner">
	</div>
</div>
<div class="lqd-preloader-wrap lqd-preloader-dot" data-preloader-options='{ "animationType": "fade" }'>
	<div class="lqd-preloader-inner">

		<div class="lqd-preloader-el">
			<div class="lqd-preloader-dot-el lqd-preloader-dot-one"></div>
			<div class="lqd-preloader-dot-el lqd-preloader-dot-two"></div>
		</div>

	</div>
</div>
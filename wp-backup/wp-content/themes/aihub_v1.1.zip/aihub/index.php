<?php
/**
 * The main template file
 *
 * @package Hub theme
 */

get_header();

get_liquid_content();

get_footer();

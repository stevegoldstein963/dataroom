<?php 
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package Hub
 * @since 1.0
 */

get_header();

get_liquid_content();

get_footer();
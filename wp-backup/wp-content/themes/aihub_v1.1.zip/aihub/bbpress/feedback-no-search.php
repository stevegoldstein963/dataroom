<?php

/**
 * No Search Results Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<div class="bbp-template-notice">
	<p><?php esc_html_e( 'Oh bother! No search results were found here!', 'aihub' ); ?></p>
</div>

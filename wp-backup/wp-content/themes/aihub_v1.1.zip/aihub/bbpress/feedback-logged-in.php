<?php

/**
 * Logged In Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<div class="bbp-template-notice info">
	<p><?php esc_html_e( 'You are already logged in.', 'aihub' ); ?></p>
</div>

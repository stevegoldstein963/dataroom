<?php

/*
 * Default sidebar template
 *
 * Check templates/sidebar.php for sidebar
 */

?>